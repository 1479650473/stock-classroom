# frontend/ — PyQt5 旧版 (LEGACY, 不再作为 UI 发展)

> **状态: legacy 维护模式**。当前主开发线是 `web/` (Tauri 2 + Vue3 + TS)。

## 为什么这个目录不能删除

虽然 PyQt5 UI 已退役，但 **backend 仍在重度依赖这里的纯逻辑模块**：

| 模块 | 被谁依赖 | 提供什么 |
|------|---------|---------|
| `frontend/plugins/research/worker.py` | backend/api/blueprints/{research,research_v2,optimize,agentops}.py, backend/agent/toolkit.py, backend/strategy/optimize_loop.py, backend/update_daily.py | `_strategy_contracts`(5策略家族契约) / `_load_frames` / `run_paper_multi` / `_flatten_rebalance_trades` / `build_paper_only` |
| `frontend/plugins/picks/panel.py` | backend/update_daily.py | `PicksPanel`(选股面板逻辑) |

## 迁移方向（后续开发可选）

把这些纯逻辑模块**迁到 `backend/strategy/` 或 `backend/legacy/`**，让 backend 完全独立于 PyQt5 前端，之后即可归档/删除本目录。当前不要动，避免破坏依赖链。

## 目录结构

- `platform/` — PyQt5 平台骨架 (platform_shell / plugin_manager / theme / premium)
- `plugins/` — 15 个功能插件 (overview/research/picks/holdings/trade/agentops/market/datacenter/datapipeline/trainer/flow/kline/agent/search/settings)
- `flow/` — 全流程指挥舱 (QWebEngineView)
- `cyq_calculator.js` — 筹码分布 JS 引擎 (本地计算)

> 注意: `frontend/platform/` 是名为 `platform` 的包，**绝不能**把它加入 PyInstaller pathex（遮蔽 stdlib platform → pandas 崩溃）。
